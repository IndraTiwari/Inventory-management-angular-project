import { WareHouseItem } from './ware-house-item';

describe('WareHouseItem', () => {
  it('should create an instance', () => {
    expect(new WareHouseItem()).toBeTruthy();
  });
});
