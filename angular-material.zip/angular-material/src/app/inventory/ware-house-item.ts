export class WareHouseItem {
    id: number;
    productName: string;
    category: string;
    availableUnits: number;
    unitPrice: number;
    location: string;
    date: string;
    description: string;
}
