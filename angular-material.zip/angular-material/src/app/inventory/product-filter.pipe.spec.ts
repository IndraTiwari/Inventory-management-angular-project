import { ProductFilterPipe } from './product-filter.pipe';

describe('ProductFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ProductFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
